//
// Created by BYU Rental on 2/5/2022.
//

#include "Datalog.h"
