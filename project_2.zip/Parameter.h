//
// Created by BYU Rental on 2/5/2022.
//

#ifndef UNTITLED_PARAMETER_H
#define UNTITLED_PARAMETER_H


class Parameter {

};


#endif //UNTITLED_PARAMETER_H
