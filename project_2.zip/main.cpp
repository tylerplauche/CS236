#include <iostream>
#include <fstream>
#include <sstream>
#include "Scanner.h"
#include "Parser.h"

using namespace std;
int main(int argc, char* argv[]) {
    //check input
    if (argc < 2)
    {
        cerr << "Please provide name of input file";

    }

    ifstream in(argv[1]);
    if (!in.is_open())
    {
        cerr << "Unable to open " << argv[1] << " for input";
        //return 1;
    }
    ostringstream os;
    os << in.rdbuf();
    string fileString = os.str();

    Scanner s = Scanner(fileString);
    s.scanTokens();


    Parser p = Parser(s.getTokenVector());
    try {
        p.datalogProgram();
    }
    catch(Token s){
        cout << "Failure!" << endl << "  " << s.toString();
    }

}